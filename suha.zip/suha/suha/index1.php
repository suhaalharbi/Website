<!Doctype html>
<html>
   <head> 
       <title>fashion</title>
       <meta charset="utf-8">
    
<style type="text/css">  
 body{
    background: url('img/ballerinas_lead_thetamsin_cooper_collection_at_the_5145b62f63.jpg')no-repeat;
    background-size:cover;
    font-family: Open Sans,Arial;
    color:white;
     margin: 0px;
     border: 0px;
     padding-top: 70px;/*the  space between nav and body*/
}
 #navigation{
            
            width:100%;
            height: 6%;
            font-size: 150%;
            background-color: black;
            position: fixed;
            top:0;
            opacity: .8;
          text-align: center;        
}
#home , #product , #about , #designer{
    
       color:whitesmoke;/*color of text */
            text-decoration: none;
            padding: 15px;      
            
}
#footer{
            
            height: 20%;
            width: 100%;
            color:whitesmoke;
            background-color: black;
            text-align: center;
            position: absolute;
            bottom:0;
            opacity: .8;
            
        }

/*java secrpt*/   
    
.fly-in-text{
    list-style:none;
    position:absolute;
    right:60%;
    top:40%;
    transform:translateX(50%) translateY(50%);
    
}
.fly-in-text li{
    display:inline-block;
    font-family: Open Sans,Arial;
    font-weight: 300;
    font-size: 9em;
    color:lightskyblue;  
    opacity:.5;
   /* border:black;*/
    transition:all 2.5s ease;
}
.fly-in-text li:last-child{
    margin-right: 0;
    
}
.fly-in-text.hidden li{
    opacity:0;
}
.fly-in-text.hidden li:nth-child(1){transform:translateX(-200px) translateY(-200px);}
.fly-in-text.hidden li:nth-child(2){transform:translateX(20px) translateY(100px);}
.fly-in-text.hidden li:nth-child(3){transform:translateX(-150px) translateY(-80px);}
.fly-in-text.hidden li:nth-child(4){transform:translateX(10px) translateY(-200px);}
.fly-in-text.hidden li:nth-child(5){transform:translateX(-300px) translateY(200px);}
.fly-in-text.hidden li:nth-child(6){transform:translateX(20px) translateY(-20px);}
.fly-in-text.hidden li:nth-child(7){transform:translateX(30px) translateY(200px);}
    /*end java secript*/
</style>
    
    
</head>
<body>
<header> 
    <!-- علشان يكون النفيقيشن بالنص -->
        <div id="navigation">
            
            <a href="index1.php" id="home">Home </a>
            <a href="product.php" id="product">products</a>
            <a href="about.php"  id="about"> About</a>
            <a href="designer.php" id="designer"> Designer</a>
            <a href="login.php"  ><img src="img/user.png" alt="login" style="width:2%;height:60%;"></a>
            <a href="regester.php" ><img src="img/Add_user_icon_(blue).svg.png" alt="fashion" style="width:2%;height:60%;"></a>
            <a href="logout.php" ><img src="img/exit-button-icon-18.png" alt="login" style="width:2%;height:60%;"> </a>
            
            
    </div>
  
            
</header>
    

    
            <!--java secript-->
            <!--https://www.youtube.com/watch?v=QZpZ1zRcR6c -->
        
            <ul class="fly-in-text hidden">
            <li>MICHAEL  </li>
            </ul>
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
            <script >
            $(function()
            {
            
             setTimeout(function(){
            $('.fly-in-text').removeClass('hidden');
                
             },500);
             })();
             </script>
           
        <!-- end java secript-->

    



    <div id="footer">
        <a href="https://www.instagram.com/michael5inco/" ><img src="img/instagram-circle-icon-1024x1024.png" alt="inst" style="width:3%;height:40%;"></a>
        <a href="https://www.facebook.com/michaelcincocouture" ><img src="img/facebook-logo-png-20.png" alt="facebook" style="width:3%;height:40%;"></a>
        <a href="https://twitter.com/michael5inco" ><img src="img/60414c58e954d7236837248225e0216f_new-twitter-logo-vector-eps-twitter-logo-clipart-png_518-518.png" alt="twitter" style="width:3%;height:40%;"></a>
        
         <p> Copyright 2000-2016 Michael Cinco LLC All Rights Reserved. Images may not be reproduced without permission.

WEBSITE MAINTAIN AND MANAGE BY: | <a href="http://www.michaelcinco.com"> CYBERADS</a></p>     
            
    
   </div>
   
    </body>    
    
   </html>