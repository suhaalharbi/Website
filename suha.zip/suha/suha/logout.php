<?php
session_start();
unset($_SESSION['username']);
session_unset();
session_destroy();
header("Location:page1.php");

exit;

{

       echo "you are log out "; 

}
