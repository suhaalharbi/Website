<!doctype html>
<html>
   <head> 
       <title>fashion</title>
       <meta charset="utf-8">
<style type="text/css">  
body{
    background-size:cover;
    font-family: Open Sans,Arial;
    color:white;
     margin: 0px;
     border: 0px;
     padding-top: 70px;/*the  space between nav and body*/
}
    video{
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%,-50%);
        min-width: 100%;
        min-height: 100%;
        width: auto;
        height: auto;
    }
   
    
 #navigation{
            
            width:100%;
            height: 6%;
            font-size: 150%;
            background-color: black;
            position: fixed;
            top:0;
            opacity: .8;
            text-align: center;
          
        
}
#home , #product , #about , #designer{
    
       color:whitesmoke;/*color of text */
            text-decoration: none;
            padding: 15px;      
            
}
            #footer{
            
            height: 20%;
            width: 100%;
            color:whitesmoke;
            background-color: black;
            text-align: center;
            position: absolute;
            bottom:0;
            opacity: .8;
            
        }

/*java secrpt*/   
    
.fly-in-text{
    list-style:none;
    position:absolute;
    right:60%;
    top:40%;
    transform:translateX(50%) translateY(50%);
    
}
.fly-in-text li{
    display:inline-block;
    font-family: Open Sans,Arial;
    font-weight: 300;
    font-size: 9em;
    color:grey;  
    opacity:.5;
    transition:all 2.5s ease;
}
.fly-in-text li:last-child{
    margin-right: 0;
    
}
.fly-in-text.hidden li{
    opacity:0;
}
.fly-in-text.hidden li:nth-child(1){transform:translateX(-200px) translateY(-200px);}
.fly-in-text.hidden li:nth-child(2){transform:translateX(20px) translateY(100px);}
.fly-in-text.hidden li:nth-child(3){transform:translateX(-150px) translateY(-80px);}
.fly-in-text.hidden li:nth-child(4){transform:translateX(10px) translateY(-200px);}
.fly-in-text.hidden li:nth-child(5){transform:translateX(-300px) translateY(200px);}
.fly-in-text.hidden li:nth-child(6){transform:translateX(20px) translateY(-20px);}
.fly-in-text.hidden li:nth-child(7){transform:translateX(30px) translateY(200px);}
    /*end java secript*/
</style>
    
    
</head>
<body>

    

    <header> 
        
    
        <video autoplay loop>
    <source src="img/33BEF55D-9BBE-4C7D-936F-8D8EDDF08F2D.mp4" type="video/mp4">
    </video>
        
        
        
        <div id="navigation">
            <a href="index1.php" id="home">Home Page </a>
 
    </div>
        

       
        
         <!--java secript-->
        <!--https://www.youtube.com/watch?v=QZpZ1zRcR6c -->
        
            <ul class="fly-in-text hidden">
            <li>Welcome </li>
            </ul>
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
            <script type="text/javascript">
            $(function()
            {
            
             setTimeout(function(){
            $('.fly-in-text').removeClass('hidden');
                
             },500);
             })();
             </script>
        
              <!-- end java secript-->
</header>
    <footer>
     <div id="footer">
        <a href="https://www.instagram.com/michael5inco/" ><img src="img/instagram-circle-icon-1024x1024.png" alt="inst" style="width:3%;height:40%;"></a>
        <a href="https://www.facebook.com/michaelcincocouture" ><img src="img/facebook-logo-png-20.png" alt="facebook" style="width:3%;height:40%;"></a>
        <a href="https://twitter.com/michael5inco" ><img src="img/60414c58e954d7236837248225e0216f_new-twitter-logo-vector-eps-twitter-logo-clipart-png_518-518.png" alt="twitter" style="width:3%;height:40%;"></a>
        
         <p> Copyright 2000-2016 Michael Cinco LLC All Rights Reserved. Images may not be reproduced without permission.

WEBSITE MAINTAIN AND MANAGE BY: | <a href="http://www.michaelcinco.com"> CYBERADS</a></p>     
            
    
   </div>
           
</footer>
    

    </body>    
    
   </html>