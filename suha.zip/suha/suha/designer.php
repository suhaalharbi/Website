<!doctype html>
<html lang="en">
   <head> 
       <title>fashion</title>
       <meta charset="utf-8">
       

<style type="text/css">  
 body{
    background-image:url('img/tumblr_mvuy1rLMdM1rhejlxo1_1280.gif');
     background-size:cover;
     font-family:Open Sans,Arial;
     color:white;
     margin: 0px;
     border: 0px;
     padding-top: 70px;/*the  space between nav and body*/
}
 #navigation{
            
            width:100%;
            height: 6%;
            font-size: 150%;
            background-color: black;
            position: fixed;
            top:0px;
            opacity: .8;
            text-align: center; 
        
}
#home , #product , #about , #designer{
    
            color:whitesmoke;/*color of text */
            text-decoration: none;
            padding: 15px;      
            
}
 h4 {
        padding: 30px;
        border: 10px;
        text-align: center;
        color:gainsboro;     
}
    h2 {
        top:1%;
        padding: 30px;
        text-align: center;
        font-family: Open Sans,Arial;
        font-size: 300%;  
        color:gainsboro;    
        opacity:.3;
    }
    
        #footer{
            
            height: 20%;
            width: 100%;
            color:whitesmoke;
            background-color: black;
            text-align: center;
            position: relative;
            bottom:0;
            opacity: .8;
            
        }
</style>
    
    
</head>
<body>
<header> 
    <!-- علشان يكون النفيقيشن بالنص -->
        <div id="navigation">
            
            <a href="index1.php" id="home">Home </a>
            <a href="product.php" id="product">products</a>
            <a href="about.php"  id="about"> About</a>
            <a href="designer.php" id="designer"> Designer</a>
            <a href="login.php"  ><img src="img/user.png" alt="login" style="width:2%;height:60%;"></a>
            <a href="regester.php" ><img src="img/Add_user_icon_(blue).svg.png" alt="fashion" style="width:2%;height:60%;"></a>
            <a href="logout.php" ><img src="img/exit-button-icon-18.png" alt="login" style="width:2%;height:60%;"> </a>
            
            
    </div>
  
            
</header>
    

           <h2>The Designer</h2>
         <img src="img/rrrrr.png" alt="fashion" style="width:90%;height:90%;margin-left:4%;">
           
            
         <h4> Dubai-based Filipino designer Michael Cinco is best known for his fabulous couture gowns. His innate creativity and masterful techniques have catapulted him to the front ranks of fashion. He has cultivated a dedicated following for the luxe and intricacy of his designs, with their fresh, elegant and detailed juxtapositions of fabric and Swarovski crystals.

           Michael’s celebrity clients include Beyonce, Jennifer Lopez, Rihanna, Lady Gaga, Carrie Underwood, Kylie Minogue, Britney Spears, Christina Aguilera, Ellie Goulding, Nicole Scherzinger, Fergie Ferguson, Dita Von Teese, Brandy, Ashanti, Chris Brown, Tyra Banks, Naomi Campbell. Jennifer Lopez wore a crystallized Michael Cinco couture when she hosted American Music Awards in 2015. Sofia Vergara wore  a stunning Michael Cinco gown at the Golden Globes 2013, who was voted Best Dressed by many TV shows and magazines in the US. British pop star Paloma Faith wore his couture dress at the MET Gala in New York. Michael also designed several costumes for Mila Kunis for the sci-fi blockbuster movie Jupiter Ascending.

           Michael was chosen by Asian Couture Federation to be one of the elite members of the best designers in Asia headed by Kenzo Tanaka and ACF President Dr. Frank Cintamani.

           In 2014 Michael was conferred with Presidential Award for Outstanding Filipinos Overseas by President Benigno Aquino Jr. for his exemplification of the talent and industry which the Philippines has to offer to the world.

           Michael appeared in US hit realty show AMERICA’s NEXT TOP MODEL Cycle 16 and All-Star Cycle 17 finale hosted by Tyra Banks. He was also chosen as guest designer and guest judge in the new reality show ASIA’s NEXT TOP MODEL, in Singapore, and was highly endorsed by Tyra Banks. He was also featured as a designer and a judge in CHINA’s NEXT TOP MODEL in 2015. </h4>
     
   
    




    <div id="footer">
        <a href="https://www.instagram.com/michael5inco/" ><img src="img/instagram-circle-icon-1024x1024.png" alt="inst" style="width:3%;height:40%;"></a>
        <a href="https://www.facebook.com/michaelcincocouture" ><img src="img/facebook-logo-png-20.png" alt="facebook" style="width:3%;height:40%;"></a>
        <a href="https://twitter.com/michael5inco" ><img src="img/60414c58e954d7236837248225e0216f_new-twitter-logo-vector-eps-twitter-logo-clipart-png_518-518.png" alt="twitter" style="width:3%;height:40%;"></a>
        
         <p> Copyright 2000-2016 Michael Cinco LLC All Rights Reserved. Images may not be reproduced without permission.

WEBSITE MAINTAIN AND MANAGE BY: | <a href="http://www.michaelcinco.com"> CYBERADS</a></p>     
            
    
   </div>

    </body>    
    
   </html>