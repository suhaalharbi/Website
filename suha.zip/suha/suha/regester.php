<?php
   session_start();
 //connect to database
   $db = mysqli_connect("localhost","root","", "cart");

   if (isset($_POST['submit']))
   {
    $username = $_POST["username"];
    $password = $_POST["pass"];
    $password1 = $_POST["pass1"];

    if($password==$password1)
    {
     $sql="INSERT INTO users (username,password)VALUES('$username','$password')";
      mysqli_query($db,$sql);
      header("location:index1.php");
    }
    else
    {
       echo "check the password not equal the other ";
    }
   }

?>

<!doctype html>
<html lang="en">
   <head> 
       <title>fashion</title>
       
       

<style type="text/css">  
 
    body{
    background: url('img/ballerinas_lead_thetamsin_cooper_collection_at_the_5145b62f63.jpg')no-repeat;
    background-size:cover;
    font-family: Open Sans,Arial;
    /*color:white;*/
     margin: 0px;
     border: 0px;
     padding-top: 70px;/*the  space between nav and body*/
    color:gray;
}
  #login1{
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        
    }
    #login1 h2 {
        color:whitesmoke;
        font-family: Open Sans,Arial;
        text-align: left;
        font-size: 130%;
    }
    #login1 input{
        display: block;
        width: 170%;
        height: 50%;
        padding: 2%;
        font-size: 100%;
        color:gray;
        font-family: Open Sans,Arial;
       /* background: rgba(0,0,0,0.3);*/
       /*outline: none;*/
       /* border: 1px solid rgba(0,0,0,0.3);*/
        border-radius: 5px;/*border for email pass*/
     /* box-shadow: inset 0px -5px 45px rgba(100,100,100,0.2),0px 1px 1px rgba(255,255,255,0.2);*/
        margin-bottom: 10px;
      /* line-height: 150%;*/
    }
    
    #login1 #submit , #login1 #clear{
        background-color: lightskyblue;
        font-size: 100%;
        text-align: center;
        vertical-align: middle;
       /* line-height: 150%;*/
        
    }
 #navigation{
            
            width:100%;
            height: 6%;
            font-size: 150%;
            background-color: black;
            position: fixed;
            top:0;
            opacity: .8;
            text-align: center;
     
        
}
#home , #product , #about , #designer{
    
           color:whitesmoke;/*color of text */
            text-decoration: none;
            padding: 15px;      
            
}
#footer{
            
            height: 20%;
            width: 100%;
            color:whitesmoke;
            background-color: black;
            text-align: center;
            position: absolute;
            bottom:0;
            opacity: .8;
            
    }
    
</style>
    
    
</head>
<body>
<header> 
    <!-- علشان يكون النفيقيشن بالنص -->
        <div id="navigation">
            
            <a href="index1.php" id="home">Home </a>
            <a href="product.php" id="product">products</a>
            <a href="about.php"  id="about"> About</a>
            <a href="designer.php" id="designer"> Designer</a>
            <a href="login.php"  ><img src="img/user.png" alt="login" style="width:2%;height:60%;"></a>
            <a href="regester.php" ><img src="img/Add_user_icon_(blue).svg.png" alt="fashion" style="width:2%;height:60%;"></a>
            <a href="logout.php" ><img src="img/exit-button-icon-18.png" alt="login" style="width:2%;height:60%;"> </a>
            
    </div>
  
            
</header>

    
        <div id="login1">
<form action="regester.php" method="post" name="login"  >
    <h2>LOGIN INFORMATION</h2>
						  
 <input id="username" type="text" name="username"  size="18" required  autofocus ><br>
 <input id="password" type="password" name="pass" size="18"   required ><br>
 <input id="password1" type="password" name="pass1" size="18"  required  ><br>
 <input  id="submit" type="submit" name="submit" value="Login">
 <input  id="clear"  type="reset" value="Clear" name="clear">
							
						  
</form>

        </div>

    
    
   

    <div id="footer">
        <a href="https://www.instagram.com/michael5inco/" ><img src="img/instagram-circle-icon-1024x1024.png" alt="inst" style="width:3%;height:40%;"></a>
        <a href="https://www.facebook.com/michaelcincocouture" ><img src="img/facebook-logo-png-20.png" alt="facebook" style="width:3%;height:40%;"></a>
        <a href="https://twitter.com/michael5inco" ><img src="img/60414c58e954d7236837248225e0216f_new-twitter-logo-vector-eps-twitter-logo-clipart-png_518-518.png" alt="twitter" style="width:3%;height:40%;"></a>
        
         <p> Copyright 2000-2016 Michael Cinco LLC All Rights Reserved. Images may not be reproduced without permission.

WEBSITE MAINTAIN AND MANAGE BY: | <a href="http://www.michaelcinco.com"> CYBERADS</a></p>     
            
    
   </div>
    

    </body>    
    
   </html>
  