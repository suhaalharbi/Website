<?php

$servername = "localhost";
$username = "root";
$password = "";
$db = "cart";

// Create connection
$connection = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$connection) {
    die("Connection failed: " . mysqli_error($connection));
}
session_start();
//echo "Connected successfully";





 ?>
