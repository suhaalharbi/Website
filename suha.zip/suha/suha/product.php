<!doctype html>
<html lang="en">
   <head> 
       <title>fashion</title>
       <meta charset="utf-8">
       
<style type="text/css">  
 body{
    background-color: black;
    background-size:cover;
    font-family: Open Sans,Arial;
     color:white;/*color all the body*/
     margin: 0px;
     border: 0px;
     padding-top: 130px;/*the  space between nav and body*/
}
 #navigation{
            
            width:100%;
            height: 6%;
            font-size: 150%;
            background-color: black;
            position: fixed;
            top:0;
            opacity: .8;
            text-align: center;
        
}
#home , #product , #about , #designer{
    
            color:whitesmoke;/*color of text */
            text-decoration: none;
            padding: 15px;      
            
}
 #footer{
            
            height: 20%;
            width: 100%;
            color:whitesmoke;
            background-color: black;
            text-align: center;
            position: relative;
            bottom:0;
            opacity: .8;
            
 }

</style>
    
    
</head>
<body>
<header> 
    <!-- علشان يكون النفيقيشن بالنص -->
        <div id="navigation">
            
            <a href="index1.php" id="home">Home </a>
            <a href="product.php" id="product">products</a>
            <a href="about.php"  id="about"> About</a>
            <a href="designer.php" id="designer"> Designer</a>
            <a href="login.php"  ><img src="img/user.png" alt="login" style="width:2%;height:60%;"></a>
            <a href="regester.php" ><img src="img/Add_user_icon_(blue).svg.png" alt="fashion" style="width:2%;height:60%;"></a>
            <a href="logout.php" ><img src="img/exit-button-icon-18.png" alt="login" style="width:2%;height:60%;"> </a>
            
            
            
            
    </div>
  
            
</header>
    

    <img src="img/95e9fa326412cd665c7325c4f968c4ea.jpg" alt="fashion" style="width:90%;height:70%; border: 70%; margin-left:3%;margin-bottom:3%;"><br>
    <img src="img/michael-cinco-2-1.jpg" alt="fashion" style="width:30%;height:70%; border: 70%; margin-left:3%;">
    <img src="img/0-JENNIFER-LOPEZ-683x1024.jpg" alt="fashion" style="width:30%;height:70%; border: 70%;">
    <img src="img/01-COVER-1-683x1024.jpg" alt="fashion" style="width:30%;height:70%; border: 70%; "><br>
    <img src="img/01-michael-cinco-fashion-forward-season-6-dubai-ready-to-wear-collection-768x1154.jpg" alt="fashion" style="width:30%;height:70%; border: 70%; margin-left:3%;">
    <img src="img/162fa505f7e618b26a9953efb2016e98.jpg" alt="fashion" style="width:30%;height:70%; border: 70%;">
    <img src="img/3b717f3b757aead38180b9ac9fb7d246.jpg" alt="fashion" style="width:30%;height:70%; border: 70%; "><br>
    <img src="img/583351057JO054_Michael_Cinc.jpg" alt="fashion" style="width:30%;height:70%; border: 70%; margin-left:3%;"><br>
    
    
  
     
    


    <div id="footer">
        <a href="https://www.instagram.com/michael5inco/" ><img src="img/instagram-circle-icon-1024x1024.png" alt="inst" style="width:3%;height:40%;"></a>
        <a href="https://www.facebook.com/michaelcincocouture" ><img src="img/facebook-logo-png-20.png" alt="facebook" style="width:3%;height:40%;"></a>
        <a href="https://twitter.com/michael5inco" ><img src="img/60414c58e954d7236837248225e0216f_new-twitter-logo-vector-eps-twitter-logo-clipart-png_518-518.png" alt="twitter" style="width:3%;height:40%;"></a>
        
         <p> Copyright 2000-2016 Michael Cinco LLC All Rights Reserved. Images may not be reproduced without permission.

WEBSITE MAINTAIN AND MANAGE BY: | <a href="http://www.michaelcinco.com"> CYBERADS</a></p>     
            
    
   </div>



    </body>    
    
   </html>