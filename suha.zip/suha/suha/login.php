<?php
   session_start();

   $connection = mysqli_connect("localhost","root","" , "cart");

   if(isset($_POST['submit']))
   {
    $username = $_POST['username'];
    $password = $_POST['pass'];




    $sql = "SELECT * FROM users WHERE username ='$username' AND password = '$password' ";
    $result = mysqli_query($connection,$sql) or die("error");

    if(mysqli_num_rows($result) == 1)
    {
      header("location:product.php");
    }
    else
    {
       echo "Invalid Username or Password!";
    }
   }
//the code for login we will take from here
//https://www.youtube.com/watch?v=NLJUQKOMIJg

?>

<!doctype html>
<html lang="en">
   <head> 
       <title>fashion</title>
       <meta charset="utf-8">
<style type="text/css">  
 body{
    background: url('img/ballerinas_lead_thetamsin_cooper_collection_at_the_5145b62f63.jpg') no-repeat;
    background-size:cover;
    font-family: Open Sans,Arial;
     margin: 0px;
     border: 0px;
     padding-top: 70px;/*the  space between nav and body*/
     color:gray;
}
  #login{
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        
    }
    #login h2 {
        color:whitesmoke;
        font-family: Open Sans,Arial;
        text-align: left;
        font-size: 130%;
    }
    #login input{
        display: block;
        width: 200%;
        height: 50%;
        padding: 2%;
        font-size: 100%;
        color:gray;
        font-family: Open Sans,Arial;
        outline: none;
        border-radius: 5px;
        margin-bottom: 10px;
    }
    
    #login #submit {
        background-color: lightskyblue;
        font-size: 100%;
        text-align: center;
        vertical-align: middle;
        
    }
 #navigation{
            
            width:100%;
            height: 6%;
            font-size: 150%;
            background-color: black;
            position: fixed;
            top:0;
            opacity: .8;
            text-align: center;
        
}
#home , #product , #about , #designer{
    
            color:whitesmoke;/*color of text */
            text-decoration: none;
            padding: 15px;      
            
}
#footer{
            
            height: 20%;
            width: 100%;
            color:whitesmoke;
            background-color: black;
            text-align: center;
            position: absolute;
            bottom:0;
            opacity: .8;
            
    }


</style>
    
    
</head>
<body>
<header> 
    <!-- علشان يكون النفيقيشن بالنص -->
        <div id="navigation">
            
            <a href="index1.php" id="home">Home </a>
            <a href="product.php" id="product">products</a>
            <a href="about.php"  id="about"> About</a>
            <a href="designer.php" id="designer"> Designer</a>
            <a href="login.php"  ><img src="img/user.png" alt="login" style="width:2%;height:60%;"></a>
            <a href="regester.php" ><img src="img/Add_user_icon_(blue).svg.png" alt="fashion" style="width:2%;height:60%;"></a>
            <a href="logout.php" ><img src="img/exit-button-icon-18.png" alt="login" style="width:2%;height:60%;"> </a>
            
            
    </div>
  
            
</header>
        
            


<div id="login">
<form action="login.php" method="post" name="login"  >
 <h2>Sing In</h2>
 <input id="username" type="text" name="username"  size="18" required autofocus ><br>
 <input id="password" type="password" name="pass" size="18"  required ><br>
 <input  id="submit" type="submit" name="submit" value="Login">
 				
						  
</form>
        </div>

    
   

    <div id="footer">
        <a href="https://www.instagram.com/michael5inco/" ><img src="img/instagram-circle-icon-1024x1024.png" alt="inst" style="width:3%;height:40%;"></a>
        <a href="https://www.facebook.com/michaelcincocouture" ><img src="img/facebook-logo-png-20.png" alt="facebook" style="width:3%;height:40%;"></a>
        <a href="https://twitter.com/michael5inco" ><img src="img/60414c58e954d7236837248225e0216f_new-twitter-logo-vector-eps-twitter-logo-clipart-png_518-518.png" alt="twitter" style="width:3%;height:40%;"></a>
        
         <p> Copyright 2000-2016 Michael Cinco LLC All Rights Reserved. Images may not be reproduced without permission.

WEBSITE MAINTAIN AND MANAGE BY: | <a href="http://www.michaelcinco.com"> CYBERADS</a></p>     
            
    
   </div>

 

    </body>    
    
   </html>